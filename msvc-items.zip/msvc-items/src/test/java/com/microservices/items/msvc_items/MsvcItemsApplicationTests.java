package com.microservices.items.msvc_items;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsvcItemsApplicationTests {

	@Test
	void contextLoads() {
	}

}
