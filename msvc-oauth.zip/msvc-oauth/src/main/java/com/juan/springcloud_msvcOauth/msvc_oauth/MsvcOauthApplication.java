package com.juan.springcloud_msvcOauth.msvc_oauth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsvcOauthApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsvcOauthApplication.class, args);
	}

}
