package com.juan.springcloud_msvcOauth.msvc_oauth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsvcOauthApplicationTests {

	@Test
	void contextLoads() {
	}

}
